# Document

Read this when they said document, docs, or README. Only the file
they named.

1. Named README / docstring / comment. Match that file's voice
   ([copy.md](../load/copy.md) if UI strings).
2. Facts the code already has. No landscape opener, no chat
   scaffolding, no unasked `SUMMARY.md` / `CHANGELOG.md`.
3. Change behavior in the same patch → update the named doc that
   would now be wrong. Don't add a new markdown file to explain
   the patch.

Don't: mermaid, extra guides, a docs site.
