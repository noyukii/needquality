# Python

Read this when touching `.py`. Core rules in `SKILL.md` still apply.

## Format

Match the file: quotes, line length, `Path` vs `os.path`. Run `ruff format`
/ `black` if the repo has it. Do not mix tab and space indent — Python
will not forgive it, and mixed indent is the classic slop tell.

Iterate the collection, not `range(len(...))`:

```python
# slop
for i in range(len(items)):
    process(items[i])

# needquality
for item in items:
    process(item)
```

Use `enumerate` only when you need the index.

## Structure

Don't invent `utils.py`, `common.py`, `helpers.py`, or a
controllers/services/dto tree for one feature. Put the function in
the module that calls it. A package split waits for a second importer.

## Errors and defaults

`except:` and `except Exception: pass` (or log-and-continue without the
exception) swallow bugs. Name the exception you can handle. Bare `except:`
is never correct.

Mutable defaults (`def f(xs=[])`) leak across calls. Use `None` and assign
inside.

Chained `.get(..., {}).get(...)` hides missing keys behind `{}`. Parse
once into a type, or fail on the missing key if it is required.

```python
# slop — missing "user" becomes a ghost success
name = payload.get("user", {}).get("name", "")

# needquality
user = payload["user"]
name = user["name"]
```

## Dispatch

A 6-branch `if x == "a": … elif x == "b"` or an `isinstance` ladder is
usually a dict of handlers or a match statement. Extract when the third
branch appears, not before.

## Time and strings

Naive `datetime.now()` has no zone. Use `datetime.now(UTC)` (or
`timezone.utc`) for instants; `zoneinfo.ZoneInfo("Europe/Amsterdam")`
for wall clock. Do not add `timedelta(days=1)` across a DST boundary
and call it tomorrow. Compare user identifiers after `unicodedata.normalize("NFC", s)`.

## Shared state

Check-then-act on a row without `SELECT … FOR UPDATE` or a
conditional `UPDATE … WHERE available` is a race. Do not hold a
`threading.Lock` across a network or sleep.

## I/O and money

`requests.get(url)` and `httpx` with `timeout=None` hang the worker.
Always pass `timeout=` (connect, read). Then `raise_for_status()` (or
check status) before `.json()`. A 500 body is not data. Do not invent
a session per call if the file already has one. `assert` is not a
trust-boundary check (`-O` strips it). Raise. A probe goes in a file
you already touch (`if __name__ == "__main__"`); do not create
`test_*.py`.

Money and rates: `Decimal`, constructed from a string — not `float`.
JSON numbers that represent money should be parsed as strings.

A view that does `for row in qs: row.user` is N+1. `select_related` /
`prefetch_related`, or a join. Querysets that can grow have
`.order_by(...)[:n]` (and a cap).

`if request.user.is_authenticated` is not "this object is theirs."
Filter by owner on the queryset.

Do not `Model.objects.filter(**request.GET)` or
`instance.__dict__.update(request.POST)` — mass assignment and
lookup injection. Allowlist fields. `pickle.loads` and `yaml.load`
on untrusted bytes are RCE; JSON or `yaml.safe_load`. User input
into `subprocess` is a list argv, never `shell=True` / `os.system`.
`eval` / `exec` of a request string is the same class.

Never `cursor.execute(f"... {q}")` — bound `%s`/`$1`. Don't concatenate
user text into `LIKE`. A new Django/SQLAlchemy field without a
migration is a prod break. Don't drop a column the running code still
reads. Schema / raw SQL: [sql.md](sql.md).

FastAPI: copy the sibling's `Depends(get_current_user)` /
`Depends(get_db)` — a module-global `db` / `current_user` is slop.
Don't skip `Depends` on the new route. Match this file's Pydantic
(`ConfigDict` / `field_validator`, not `@validator` / `class Config`
on a v2 model). If the tree already has `APIRouter` modules, add the
route there — not a new dump in `main.py`. `async def` only when this
file awaits; don't make every endpoint async. `return {"error": …}`
with 200 is not an error — `HTTPException`. Don't
`asyncio.create_task` for request work the file already does with
`BackgroundTasks`.

## Leftovers

No `print(...)` in production modules. No unused imports or unused
bindings. A used name is imported. Don't shadow `dict` / `list` /
`id` / `type`. Don't `if cond: return True` / `else: return False`
— `return cond`. Else after `return` is noise. Same expression
twice in one function → bind. Don't invent a dense
`reduce`/`lambda` one-liner next to a for-loop file; match this
file's comprehension vs append. Do not leak JS idioms (`.push`,
`.forEach`, `===`). `assert True` is not a test. No
hardcoded `sk-` / `AKIA` / connection strings. Do not ship `DEBUG=True`
or `ALLOWED_HOSTS=['*']`.

TLS: never `requests.get(..., verify=False)` / `httpx verify=False`.
Never `open(os.path.join(UPLOAD_DIR, filename))` / `send_file` of a
user path; never `tarfile.extractall` / `shutil.unpack_archive` outside
a directory you created. Don't `requests.get(request.GET["url"])`.
CSRF / JWT / webhooks: [trust.md](trust.md) when this patch does HTTP.

Jinja: user text is *context*, never `Template(user)` / `from_string(user)`.
Passwords: argon2/bcrypt / `make_password` — not `hashlib.md5`, not
`User.password == request.form['password']`. Don't
`asyncio.gather(*[fn(i) for i in body["ids"]])` unbounded. Don't add
`# noqa` / `ruff: noqa` to silence a diagnostic you introduced.
Tokens: `secrets`, not `random.random`.
